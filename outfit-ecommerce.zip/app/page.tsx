import { SiteHeader } from "@/components/site-header"
import { OutfitShowcase } from "@/components/outfit-showcase"
import { FeaturedOutfits } from "@/components/featured-outfits"
import { CategoryFilter } from "@/components/category-filter"
import { Newsletter } from "@/components/newsletter"
import { SiteFooter } from "@/components/site-footer"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-b from-muted/50 to-background py-12 md:py-16 lg:py-20">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
                    Discover Perfect Outfit Combinations
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    Shop complete looks from your favorite brands. One click to find the perfect style.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <a
                    href="#featured"
                    className="inline-flex h-10 items-center justify-center rounded-md bg-primary px-8 text-sm font-medium text-primary-foreground shadow transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50"
                  >
                    Shop Now
                  </a>
                  <a
                    href="#categories"
                    className="inline-flex h-10 items-center justify-center rounded-md border border-input bg-background px-8 text-sm font-medium shadow-sm transition-colors hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50"
                  >
                    Browse Categories
                  </a>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="relative h-[300px] w-full overflow-hidden rounded-lg md:h-[400px]">
                  <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-secondary/20 backdrop-blur-sm"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="grid grid-cols-3 gap-4">
                      <div className="flex flex-col items-center space-y-2 rounded-lg bg-background/80 p-4 shadow-lg backdrop-blur">
                        <div className="relative h-16 w-16 overflow-hidden rounded-full">
                          <img
                            src="/placeholder.svg?height=64&width=64"
                            alt="Clothing item"
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <span className="text-xs font-medium">Shirts</span>
                      </div>
                      <div className="flex flex-col items-center space-y-2 rounded-lg bg-background/80 p-4 shadow-lg backdrop-blur">
                        <div className="relative h-16 w-16 overflow-hidden rounded-full">
                          <img
                            src="/placeholder.svg?height=64&width=64"
                            alt="Clothing item"
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <span className="text-xs font-medium">Pants</span>
                      </div>
                      <div className="flex flex-col items-center space-y-2 rounded-lg bg-background/80 p-4 shadow-lg backdrop-blur">
                        <div className="relative h-16 w-16 overflow-hidden rounded-full">
                          <img
                            src="/placeholder.svg?height=64&width=64"
                            alt="Clothing item"
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <span className="text-xs font-medium">Shoes</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Categories Section */}
        <section id="categories" className="py-12 md:py-16 lg:py-20">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Shop by Style</h2>
                <p className="max-w-[700px] text-muted-foreground md:text-xl">
                  Find the perfect outfit combination for any occasion.
                </p>
              </div>
            </div>
            <CategoryFilter />
          </div>
        </section>

        {/* Featured Outfits */}
        <section id="featured" className="bg-muted/50 py-12 md:py-16 lg:py-20">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Featured Combinations</h2>
                <p className="max-w-[700px] text-muted-foreground md:text-xl">
                  Curated outfit combinations from top brands.
                </p>
              </div>
            </div>
            <FeaturedOutfits />
          </div>
        </section>

        {/* Outfit Showcase */}
        <section className="py-12 md:py-16 lg:py-20">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Explore Outfits</h2>
                <p className="max-w-[700px] text-muted-foreground md:text-xl">
                  Browse our complete collection of outfit combinations.
                </p>
              </div>
            </div>
            <OutfitShowcase />
          </div>
        </section>

        {/* Newsletter */}
        <section className="bg-muted/50 py-12 md:py-16 lg:py-20">
          <div className="container px-4 md:px-6">
            <Newsletter />
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}
