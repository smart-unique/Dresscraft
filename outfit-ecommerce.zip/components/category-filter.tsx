"use client"

import { useState } from "react"
import { motion } from "framer-motion"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const categories = [
  {
    id: "casual",
    name: "Casual",
    image: "/placeholder.svg?height=200&width=200",
    count: 24,
  },
  {
    id: "formal",
    name: "Formal",
    image: "/placeholder.svg?height=200&width=200",
    count: 18,
  },
  {
    id: "athletic",
    name: "Athletic",
    image: "/placeholder.svg?height=200&width=200",
    count: 16,
  },
  {
    id: "business",
    name: "Business",
    image: "/placeholder.svg?height=200&width=200",
    count: 12,
  },
  {
    id: "evening",
    name: "Evening",
    image: "/placeholder.svg?height=200&width=200",
    count: 9,
  },
  {
    id: "summer",
    name: "Summer",
    image: "/placeholder.svg?height=200&width=200",
    count: 21,
  },
]

export function CategoryFilter() {
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null)

  return (
    <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-6">
      {categories.map((category) => (
        <motion.div
          key={category.id}
          className="cursor-pointer"
          whileHover={{ scale: 1.05 }}
          onMouseEnter={() => setHoveredCategory(category.id)}
          onMouseLeave={() => setHoveredCategory(null)}
        >
          <Card className="overflow-hidden">
            <div className="relative aspect-square overflow-hidden">
              <img
                src={category.image || "/placeholder.svg"}
                alt={category.name}
                className="h-full w-full object-cover transition-transform duration-300 ease-in-out hover:scale-110"
              />
              <div className="absolute inset-0 bg-black/20" />
              <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center text-white">
                <h3 className="text-lg font-bold">{category.name}</h3>
                <Badge variant="secondary" className="mt-2">
                  {category.count} outfits
                </Badge>
              </div>
            </div>
          </Card>
        </motion.div>
      ))}
    </div>
  )
}
