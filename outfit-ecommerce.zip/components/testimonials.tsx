"use client"

import { useState } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight, Quote } from "lucide-react"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const testimonials = [
  {
    quote:
      "Working with this team has been an absolute pleasure. They delivered our website on time and exceeded all our expectations.",
    author: "Sarah Johnson",
    title: "CEO, TechStart Inc.",
    avatar: "/placeholder.svg?height=100&width=100",
  },
  {
    quote:
      "The attention to detail and commitment to quality is unmatched. Our e-commerce sales have increased by 200% since launching our new website.",
    author: "Michael Chen",
    title: "Founder, StyleShop",
    avatar: "/placeholder.svg?height=100&width=100",
  },
  {
    quote:
      "Their team took the time to understand our business needs and delivered a solution that perfectly aligned with our goals.",
    author: "Emily Rodriguez",
    title: "Marketing Director, GrowthCo",
    avatar: "/placeholder.svg?height=100&width=100",
  },
  {
    quote:
      "The website they built for us has received countless compliments from our customers. It's both beautiful and functional.",
    author: "David Kim",
    title: "Owner, Artisan Crafts",
    avatar: "/placeholder.svg?height=100&width=100",
  },
]

export function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [direction, setDirection] = useState<"left" | "right" | null>(null)

  const nextTestimonial = () => {
    setDirection("right")
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length)
  }

  const prevTestimonial = () => {
    setDirection("left")
    setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length)
  }

  return (
    <div className="relative mx-auto max-w-4xl py-12">
      <div className="absolute left-0 top-1/2 -translate-y-1/2">
        <Button variant="outline" size="icon" onClick={prevTestimonial} className="rounded-full">
          <ChevronLeft className="h-6 w-6" />
          <span className="sr-only">Previous testimonial</span>
        </Button>
      </div>
      <div className="absolute right-0 top-1/2 -translate-y-1/2">
        <Button variant="outline" size="icon" onClick={nextTestimonial} className="rounded-full">
          <ChevronRight className="h-6 w-6" />
          <span className="sr-only">Next testimonial</span>
        </Button>
      </div>
      <div className="overflow-hidden px-12">
        <div
          className="flex transition-transform duration-500 ease-in-out"
          style={{
            transform: `translateX(-${currentIndex * 100}%)`,
          }}
        >
          {testimonials.map((testimonial, index) => (
            <div key={index} className="w-full flex-shrink-0 px-4">
              <Card className="border-none shadow-none">
                <CardContent className="flex flex-col items-center p-6 text-center">
                  <Quote className="mb-6 h-12 w-12 text-primary/20" />
                  <p className="mb-6 text-xl italic text-muted-foreground">"{testimonial.quote}"</p>
                  <div className="mt-4 flex flex-col items-center">
                    <div className="relative mb-4 h-16 w-16 overflow-hidden rounded-full">
                      <Image
                        src={testimonial.avatar || "/placeholder.svg"}
                        alt={testimonial.author}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="text-center">
                      <h3 className="font-bold">{testimonial.author}</h3>
                      <p className="text-sm text-muted-foreground">{testimonial.title}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </div>
      <div className="mt-6 flex justify-center space-x-2">
        {testimonials.map((_, index) => (
          <button
            key={index}
            className={`h-2 w-2 rounded-full ${index === currentIndex ? "bg-primary" : "bg-primary/20"}`}
            onClick={() => setCurrentIndex(index)}
          />
        ))}
      </div>
    </div>
  )
}
