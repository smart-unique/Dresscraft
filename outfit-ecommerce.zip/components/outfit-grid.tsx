"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ExternalLink } from "lucide-react"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"

// Sample data for outfit combinations
const outfits = [
  {
    id: 1,
    title: "Casual Summer Look",
    items: [
      {
        id: 101,
        name: "Cotton T-Shirt",
        price: 24.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Gap",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.gap.com",
      },
      {
        id: 102,
        name: "Denim Shorts",
        price: 39.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Levi's",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.levis.com",
      },
      {
        id: 103,
        name: "Canvas Sneakers",
        price: 54.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Converse",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.converse.com",
      },
    ],
  },
  {
    id: 2,
    title: "Business Casual",
    items: [
      {
        id: 201,
        name: "Oxford Shirt",
        price: 59.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "J.Crew",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.jcrew.com",
      },
      {
        id: 202,
        name: "Chino Pants",
        price: 49.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Banana Republic",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.bananarepublic.com",
      },
      {
        id: 203,
        name: "Leather Loafers",
        price: 89.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Cole Haan",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.colehaan.com",
      },
    ],
  },
  {
    id: 3,
    title: "Workout Essentials",
    items: [
      {
        id: 301,
        name: "Performance Tee",
        price: 34.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Under Armour",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.underarmour.com",
      },
      {
        id: 302,
        name: "Athletic Shorts",
        price: 29.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Nike",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.nike.com",
      },
      {
        id: 303,
        name: "Running Shoes",
        price: 119.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Adidas",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.adidas.com",
      },
    ],
  },
  {
    id: 4,
    title: "Evening Out",
    items: [
      {
        id: 401,
        name: "Dress Shirt",
        price: 69.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Calvin Klein",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.calvinklein.com",
      },
      {
        id: 402,
        name: "Slim Fit Jeans",
        price: 79.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Diesel",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.diesel.com",
      },
      {
        id: 403,
        name: "Leather Boots",
        price: 149.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Timberland",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.timberland.com",
      },
    ],
  },
]

export default function OutfitGrid() {
  const [selectedOutfit, setSelectedOutfit] = useState(outfits[0])

  return (
    <div className="space-y-8">
      <div className="flex space-x-2 pb-4">
        {outfits.map((outfit) => (
          <Button
            key={outfit.id}
            variant={selectedOutfit.id === outfit.id ? "default" : "outline"}
            onClick={() => setSelectedOutfit(outfit)}
            className="whitespace-nowrap"
          >
            {outfit.title}
          </Button>
        ))}
      </div>

      <Card className="border-2">
        <CardContent className="p-6">
          <div className="mb-4">
            <h2 className="text-2xl font-bold">{selectedOutfit.title}</h2>
            <p className="text-muted-foreground">Complete outfit combination with items from different brands</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            {selectedOutfit.items.map((item) => (
              <div
                key={item.id}
                className="flex flex-col items-center p-4 border rounded-lg hover:shadow-md transition-shadow"
              >
                <div className="relative mb-4">
                  <Image
                    src={item.image || "/placeholder.svg"}
                    alt={item.name}
                    width={120}
                    height={120}
                    className="object-contain"
                  />
                </div>
                <h3 className="font-medium text-center">{item.name}</h3>
                <p className="text-lg font-bold mt-2">${item.price.toFixed(2)}</p>
              </div>
            ))}
          </div>

          <div className="border-t pt-6">
            <h3 className="text-lg font-semibold mb-4">Shop Individual Items</h3>
            <ScrollArea className="w-full whitespace-nowrap">
              <div className="flex space-x-4">
                {selectedOutfit.items.map((item) => (
                  <Link
                    href={item.url}
                    key={item.id}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex flex-col items-center p-4 border rounded-lg hover:bg-muted transition-colors min-w-[200px]"
                  >
                    <div className="flex items-center justify-center h-12 mb-2">
                      <Image
                        src={item.companyLogo || "/placeholder.svg"}
                        alt={item.company}
                        width={60}
                        height={30}
                        className="object-contain"
                      />
                    </div>
                    <div className="flex items-center justify-center mb-2">
                      <Image
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        width={80}
                        height={80}
                        className="object-contain"
                      />
                    </div>
                    <p className="text-center font-medium">{item.name}</p>
                    <p className="text-center font-bold mt-1">${item.price.toFixed(2)}</p>
                    <Badge variant="outline" className="mt-2 flex items-center gap-1">
                      {item.company} <ExternalLink className="h-3 w-3" />
                    </Badge>
                  </Link>
                ))}
              </div>
              <ScrollBar orientation="horizontal" />
            </ScrollArea>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
