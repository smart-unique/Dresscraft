"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, ExternalLink } from "lucide-react"
import { motion } from "framer-motion"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

// Sample data for featured outfit combinations
const featuredOutfits = [
  {
    id: 1,
    title: "Summer Essentials",
    description: "Perfect for warm days and casual outings",
    items: [
      {
        id: 101,
        name: "Linen Shirt",
        price: 49.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Zara",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.zara.com",
      },
      {
        id: 102,
        name: "Chino Shorts",
        price: 39.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "H&M",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.hm.com",
      },
      {
        id: 103,
        name: "Espadrilles",
        price: 59.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "TOMS",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.toms.com",
      },
    ],
  },
  {
    id: 2,
    title: "Office Ready",
    description: "Professional attire for the modern workplace",
    items: [
      {
        id: 201,
        name: "Slim Fit Blazer",
        price: 149.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Banana Republic",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.bananarepublic.com",
      },
      {
        id: 202,
        name: "Dress Shirt",
        price: 69.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Brooks Brothers",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.brooksbrothers.com",
      },
      {
        id: 203,
        name: "Leather Oxfords",
        price: 129.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Johnston & Murphy",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.johnstonmurphy.com",
      },
    ],
  },
  {
    id: 3,
    title: "Weekend Getaway",
    description: "Comfortable and stylish for your weekend trips",
    items: [
      {
        id: 301,
        name: "Denim Jacket",
        price: 89.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Levi's",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.levis.com",
      },
      {
        id: 302,
        name: "Slim Jeans",
        price: 79.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Gap",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.gap.com",
      },
      {
        id: 303,
        name: "Canvas Sneakers",
        price: 69.99,
        image: "/placeholder.svg?height=120&width=120",
        company: "Converse",
        companyLogo: "/placeholder.svg?height=30&width=60",
        url: "https://www.converse.com",
      },
    ],
  },
]

export function FeaturedOutfits() {
  const [currentOutfit, setCurrentOutfit] = useState(0)

  const nextOutfit = () => {
    setCurrentOutfit((prev) => (prev + 1) % featuredOutfits.length)
  }

  const prevOutfit = () => {
    setCurrentOutfit((prev) => (prev - 1 + featuredOutfits.length) % featuredOutfits.length)
  }

  const outfit = featuredOutfits[currentOutfit]

  return (
    <div className="mt-8">
      <div className="relative">
        <Card className="overflow-hidden">
          <CardContent className="p-6">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">{outfit.title}</h2>
                <p className="text-muted-foreground">{outfit.description}</p>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" onClick={prevOutfit} className="rounded-full">
                  <ChevronLeft className="h-4 w-4" />
                  <span className="sr-only">Previous outfit</span>
                </Button>
                <span className="text-sm">
                  {currentOutfit + 1} / {featuredOutfits.length}
                </span>
                <Button variant="outline" size="icon" onClick={nextOutfit} className="rounded-full">
                  <ChevronRight className="h-4 w-4" />
                  <span className="sr-only">Next outfit</span>
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
              {outfit.items.map((item, index) => (
                <motion.div
                  key={item.id}
                  className="flex flex-col items-center rounded-lg border p-4 transition-all hover:shadow-md"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  <div className="relative mb-4 flex h-32 w-32 items-center justify-center">
                    <img
                      src={item.image || "/placeholder.svg"}
                      alt={item.name}
                      className="h-full w-full object-contain"
                    />
                  </div>
                  <h3 className="text-center font-medium">{item.name}</h3>
                  <p className="mt-2 text-lg font-bold">${item.price.toFixed(2)}</p>
                  <div className="mt-2 flex h-8 w-full items-center justify-center">
                    <img
                      src={item.companyLogo || "/placeholder.svg"}
                      alt={item.company}
                      className="h-full object-contain"
                    />
                  </div>
                  <a
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-4 inline-flex items-center gap-1 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
                  >
                    Shop at {item.company} <ExternalLink className="ml-1 h-3 w-3" />
                  </a>
                </motion.div>
              ))}
            </div>

            <div className="mt-6 flex justify-center">
              {featuredOutfits.map((_, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  size="icon"
                  className={`h-2 w-2 rounded-full p-0 ${index === currentOutfit ? "bg-primary" : "bg-muted"}`}
                  onClick={() => setCurrentOutfit(index)}
                >
                  <span className="sr-only">Go to outfit {index + 1}</span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
