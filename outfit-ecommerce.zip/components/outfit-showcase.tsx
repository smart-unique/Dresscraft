"use client"

import { useState } from "react"
import { ExternalLink, ChevronLeft, ChevronRight } from "lucide-react"
import { motion } from "framer-motion"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Sample data for outfit combinations
const outfitCategories = [
  {
    id: "casual",
    name: "Casual",
    outfits: [
      {
        id: 1,
        title: "Weekend Casual",
        items: [
          {
            id: 101,
            name: "Premium Cotton T-Shirt",
            price: 29.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "Gap",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.gap.com",
          },
          {
            id: 102,
            name: "Slim Fit Jeans",
            price: 59.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "Levi's",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.levis.com",
          },
          {
            id: 103,
            name: "Classic Sneakers",
            price: 79.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "Nike",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.nike.com",
          },
        ],
      },
      {
        id: 2,
        title: "Relaxed Fit",
        items: [
          {
            id: 201,
            name: "Oversized Hoodie",
            price: 49.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "H&M",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.hm.com",
          },
          {
            id: 202,
            name: "Jogger Pants",
            price: 39.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "Adidas",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.adidas.com",
          },
          {
            id: 203,
            name: "Slip-on Shoes",
            price: 64.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "Vans",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.vans.com",
          },
        ],
      },
    ],
  },
  {
    id: "formal",
    name: "Formal",
    outfits: [
      {
        id: 3,
        title: "Business Professional",
        items: [
          {
            id: 301,
            name: "Tailored Suit Jacket",
            price: 199.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "Hugo Boss",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.hugoboss.com",
          },
          {
            id: 302,
            name: "Dress Pants",
            price: 89.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "Calvin Klein",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.calvinklein.com",
          },
          {
            id: 303,
            name: "Oxford Shoes",
            price: 149.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "Cole Haan",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.colehaan.com",
          },
        ],
      },
      {
        id: 4,
        title: "Smart Casual",
        items: [
          {
            id: 401,
            name: "Button-Down Shirt",
            price: 69.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "J.Crew",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.jcrew.com",
          },
          {
            id: 402,
            name: "Chino Pants",
            price: 59.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "Banana Republic",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.bananarepublic.com",
          },
          {
            id: 403,
            name: "Leather Loafers",
            price: 119.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "Clarks",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.clarks.com",
          },
        ],
      },
    ],
  },
  {
    id: "athletic",
    name: "Athletic",
    outfits: [
      {
        id: 5,
        title: "Workout Ready",
        items: [
          {
            id: 501,
            name: "Performance T-Shirt",
            price: 34.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "Under Armour",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.underarmour.com",
          },
          {
            id: 502,
            name: "Training Shorts",
            price: 29.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "Nike",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.nike.com",
          },
          {
            id: 503,
            name: "Running Shoes",
            price: 129.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "Asics",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.asics.com",
          },
        ],
      },
      {
        id: 6,
        title: "Athleisure",
        items: [
          {
            id: 601,
            name: "Zip-Up Jacket",
            price: 79.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "Lululemon",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.lululemon.com",
          },
          {
            id: 602,
            name: "Yoga Pants",
            price: 89.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "Athleta",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.athleta.com",
          },
          {
            id: 603,
            name: "Lifestyle Sneakers",
            price: 99.99,
            image: "/placeholder.svg?height=120&width=120",
            company: "New Balance",
            companyLogo: "/placeholder.svg?height=30&width=60",
            url: "https://www.newbalance.com",
          },
        ],
      },
    ],
  },
]

export function OutfitShowcase() {
  const [selectedOutfit, setSelectedOutfit] = useState(outfitCategories[0].outfits[0])
  const [currentCategory, setCurrentCategory] = useState(outfitCategories[0].id)

  const currentCategoryData = outfitCategories.find((category) => category.id === currentCategory)

  const handleOutfitChange = (outfitId: number) => {
    const outfit = currentCategoryData?.outfits.find((o) => o.id === outfitId)
    if (outfit) {
      setSelectedOutfit(outfit)
    }
  }

  return (
    <div className="mt-8 space-y-8">
      <Tabs defaultValue={currentCategory} onValueChange={setCurrentCategory}>
        <TabsList className="grid w-full grid-cols-3">
          {outfitCategories.map((category) => (
            <TabsTrigger key={category.id} value={category.id}>
              {category.name}
            </TabsTrigger>
          ))}
        </TabsList>
        {outfitCategories.map((category) => (
          <TabsContent key={category.id} value={category.id} className="space-y-8">
            <div className="flex flex-wrap gap-4">
              {category.outfits.map((outfit) => (
                <Button
                  key={outfit.id}
                  variant={selectedOutfit.id === outfit.id ? "default" : "outline"}
                  onClick={() => handleOutfitChange(outfit.id)}
                >
                  {outfit.title}
                </Button>
              ))}
            </div>

            <Card className="overflow-hidden border-2">
              <CardContent className="p-6">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold">{selectedOutfit.title}</h2>
                  <p className="text-muted-foreground">Complete outfit combination with items from different brands</p>
                </div>

                <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
                  {selectedOutfit.items.map((item) => (
                    <motion.div
                      key={item.id}
                      className="flex flex-col items-center rounded-lg border p-4 transition-all hover:shadow-md"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="relative mb-4 flex h-32 w-32 items-center justify-center">
                        <img
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          className="h-full w-full object-contain"
                        />
                      </div>
                      <h3 className="text-center font-medium">{item.name}</h3>
                      <p className="mt-2 text-lg font-bold">${item.price.toFixed(2)}</p>
                      <div className="mt-2 flex h-8 w-full items-center justify-center">
                        <img
                          src={item.companyLogo || "/placeholder.svg"}
                          alt={item.company}
                          className="h-full object-contain"
                        />
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-8 border-t pt-6">
                  <h3 className="mb-4 text-lg font-semibold">Shop Individual Items</h3>
                  <ScrollArea className="w-full whitespace-nowrap pb-4">
                    <div className="flex space-x-4">
                      {selectedOutfit.items.map((item) => (
                        <a
                          href={item.url}
                          key={item.id}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex min-w-[220px] flex-col items-center rounded-lg border p-4 transition-colors hover:bg-muted"
                        >
                          <div className="mb-2 flex h-12 items-center justify-center">
                            <img
                              src={item.companyLogo || "/placeholder.svg"}
                              alt={item.company}
                              className="h-full object-contain"
                            />
                          </div>
                          <div className="mb-2 flex h-24 w-24 items-center justify-center">
                            <img
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              className="h-full w-full object-contain"
                            />
                          </div>
                          <p className="text-center font-medium">{item.name}</p>
                          <p className="mt-1 text-center font-bold">${item.price.toFixed(2)}</p>
                          <Badge variant="outline" className="mt-2 flex items-center gap-1">
                            {item.company} <ExternalLink className="h-3 w-3" />
                          </Badge>
                        </a>
                      ))}
                    </div>
                    <ScrollBar orientation="horizontal" />
                  </ScrollArea>
                  <div className="mt-4 flex items-center justify-center gap-2 md:hidden">
                    <Button variant="outline" size="icon" className="rounded-full">
                      <ChevronLeft className="h-4 w-4" />
                      <span className="sr-only">Scroll left</span>
                    </Button>
                    <Button variant="outline" size="icon" className="rounded-full">
                      <ChevronRight className="h-4 w-4" />
                      <span className="sr-only">Scroll right</span>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
